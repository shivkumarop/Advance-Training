package com.problem_statement_2_2;

public class FibonacciNumbers {
	



		public static void main(String[] args) {

			int i = 1, n = 13, firstNum = 1, secondNum = 3;
			System.out.println("The First Two Numbers Are:"+firstNum + " "+secondNum);
			System.out.println("Fibonacci Series till " + n + " terms:");

			while (i <= n) {
				System.out.print(firstNum + ", ");

				int Temp = firstNum + secondNum;
				firstNum = secondNum;
				secondNum = Temp;

				i++;
			}
		}
	}

